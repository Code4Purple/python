# 💰 LedgerLite — Personal Finance Checkbook Website

A complete, self-contained Python project that generates and serves your full
marketing website. One command. Works anywhere Python is installed.

---

## 🚀 Quick Start

```bash
python launch.py
```

That's it. The script will:
1. Auto-install any missing Python packages
2. Generate all HTML pages from your config
3. Start a local web server on http://localhost:8080
4. Open your browser automatically

Press `Ctrl+C` to stop.

---

## 📁 Project Structure

```
finance_checkbook/
│
├── launch.py        ← RUN THIS — the single entry point
├── config.py        ← EDIT THIS — all your content lives here
├── generator.py     ← Site builder (no need to edit)
│
├── static/          ← Drop in images, custom CSS, JS here
│   ├── images/
│   ├── css/
│   └── js/
│
└── dist/            ← Auto-generated output (don't edit manually)
    ├── index.html
    ├── pricing.html
    ├── features.html
    └── signup.html
```

---

## ✏️ Customizing Your Site

**Everything lives in `config.py`.** Edit any of these sections:

| Section | What it controls |
|---|---|
| `brand` | Name, tagline, colors, fonts |
| `seo` | Title, meta description, social sharing |
| `nav` | Navigation links and CTA |
| `homepage.hero` | Headline, subheadline, CTA buttons |
| `homepage.features` | Feature cards (icon, name, description) |
| `homepage.testimonials` | Customer quotes |
| `homepage.faq` | FAQ questions and answers |
| `pricing.plans` | Plan names, prices, feature lists |
| `features_page` | Deep feature detail and comparison table |
| `signup` | Sign up page benefits and form |
| `footer` | Footer links and copyright |

After editing `config.py`, just run `python launch.py` again to rebuild.

---

## 🌐 Deploying to the Web

Your site is in the `dist/` folder — plain HTML/CSS/JS, no server needed.

**Netlify (drag & drop — free):**
1. Go to https://netlify.com
2. Drag your `dist/` folder onto the deploy page
3. Done — you get a live URL instantly

**Vercel (CLI — free):**
```bash
npm i -g vercel
cd dist
vercel
```

**GitHub Pages:**
1. Push `dist/` contents to a `gh-pages` branch
2. Enable GitHub Pages in repo settings

---

## 🐍 Requirements

- Python 3.8 or higher
- Internet connection for first run (to install `jinja2` and load Google Fonts)
- No other dependencies — everything else is built-in Python

---

## 🔁 Workflow

```
Edit config.py → python launch.py → view at localhost:8080 → repeat
```

To deploy: drag `dist/` to Netlify or push to your host.

---

## 📦 Packages Auto-Installed

| Package | Purpose |
|---|---|
| `jinja2` | HTML template rendering |

---

Made with Python · No frameworks · No build tools · Just run and go.
