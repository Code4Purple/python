"""
generator.py — Builds the entire site from config + templates.
Called automatically by launch.py. You don't need to edit this.
"""

import shutil
from pathlib import Path
from jinja2 import Environment, FileSystemLoader, select_autoescape


def build_site(config: dict, output_dir: Path):
    """Generate all HTML pages and static assets into output_dir."""

    # Clean and recreate output directory
    if output_dir.exists():
        shutil.rmtree(output_dir)
    output_dir.mkdir(parents=True)

    base_dir = Path(__file__).parent

    # Copy static assets if they exist
    static_src = base_dir / "static"
    if static_src.exists():
        shutil.copytree(static_src, output_dir / "static")

    # Set up Jinja2 from inline templates (no separate files needed)
    env = Environment(autoescape=select_autoescape(["html"]))

    # Inject shared CSS as a variable
    config["_css"] = _build_css(config)
    config["_nav_html"] = ""  # filled per-page below

    pages = {
        "index.html":    _render_homepage,
        "pricing.html":  _render_pricing,
        "features.html": _render_features,
        "signup.html":   _render_signup,
    }

    for filename, renderer in pages.items():
        html = renderer(config, env)
        (output_dir / filename).write_text(html, encoding="utf-8")
        print(f"      → {filename}")


# ── CSS Generator ─────────────────────────────────────────────────────────────

def _build_css(cfg: dict) -> str:
    c = cfg["brand"]["colors"]
    fh = cfg["brand"]["font_heading"]
    fb = cfg["brand"]["font_body"]
    return f"""
/* ── Reset & Base ── */
*,*::before,*::after{{box-sizing:border-box;margin:0;padding:0}}
html{{scroll-behavior:smooth}}
body{{font-family:{fb};font-size:16px;line-height:1.7;color:{c['dark']};background:{c['light']}}}
a{{color:{c['primary']};text-decoration:none}}
a:hover{{text-decoration:underline}}
img{{max-width:100%;display:block}}
h1,h2,h3,h4{{font-family:{fh};line-height:1.2;color:{c['dark']}}}

/* ── CSS Variables ── */
:root{{
  --primary:{c['primary']};
  --primary-light:{c['primary_light']};
  --primary-mid:{c['primary_mid']};
  --accent:{c['accent']};
  --dark:{c['dark']};
  --mid:{c['mid']};
  --light:{c['light']};
  --white:{c['white']};
  --border:{c['border']};
  --radius:10px;
  --shadow:0 2px 12px rgba(0,0,0,.08);
  --max:1100px;
}}

/* ── Layout ── */
.container{{max-width:var(--max);margin:0 auto;padding:0 24px}}
.section{{padding:80px 0}}
.section-sm{{padding:48px 0}}
.grid-2{{display:grid;grid-template-columns:1fr 1fr;gap:48px;align-items:center}}
.grid-3{{display:grid;grid-template-columns:repeat(3,1fr);gap:24px}}
.grid-auto{{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:24px}}
.text-center{{text-align:center}}
.text-mid{{color:var(--mid)}}
.mt-8{{margin-top:8px}}
.mt-16{{margin-top:16px}}
.mt-24{{margin-top:24px}}
.mt-40{{margin-top:40px}}
.mb-8{{margin-bottom:8px}}
.mb-16{{margin-bottom:16px}}
.mb-40{{margin-bottom:40px}}

/* ── Buttons ── */
.btn{{display:inline-block;padding:14px 28px;border-radius:var(--radius);font-family:{fb};font-size:15px;font-weight:600;cursor:pointer;transition:.2s;border:none;text-decoration:none}}
.btn-primary{{background:var(--primary);color:#fff}}
.btn-primary:hover{{background:var(--primary-mid);text-decoration:none;color:#fff}}
.btn-secondary{{background:transparent;color:var(--primary);border:1.5px solid var(--primary)}}
.btn-secondary:hover{{background:var(--primary-light);text-decoration:none}}
.btn-accent{{background:var(--accent);color:#fff}}
.btn-accent:hover{{background:#d4920a;text-decoration:none;color:#fff}}
.btn-lg{{padding:16px 36px;font-size:16px}}
.btn-sm{{padding:8px 18px;font-size:13px}}

/* ── Nav ── */
.nav{{position:sticky;top:0;background:rgba(255,255,255,.96);backdrop-filter:blur(8px);border-bottom:1px solid var(--border);z-index:100}}
.nav-inner{{display:flex;align-items:center;gap:24px;height:64px}}
.nav-logo{{font-family:{fh};font-size:22px;color:var(--primary);font-weight:400;margin-right:auto}}
.nav-logo:hover{{text-decoration:none}}
.nav-links{{display:flex;gap:24px;list-style:none}}
.nav-links a{{font-size:14px;color:var(--dark);font-weight:500}}
.nav-links a:hover{{color:var(--primary);text-decoration:none}}
.nav-login{{font-size:14px;color:var(--mid);font-weight:500}}
.nav-gap{{margin-left:8px}}

/* ── Hero ── */
.hero{{padding:96px 0 80px;text-align:center}}
.hero h1{{font-size:clamp(2rem,5vw,3.5rem);max-width:800px;margin:0 auto}}
.hero-sub{{font-size:18px;color:var(--mid);max-width:580px;margin:20px auto 0}}
.hero-ctas{{display:flex;gap:16px;justify-content:center;margin-top:36px;flex-wrap:wrap}}
.trust-line{{font-size:13px;color:var(--mid);margin-top:16px}}
.hero-mockup{{background:var(--white);border:1px solid var(--border);border-radius:16px;box-shadow:0 8px 40px rgba(0,0,0,.1);margin-top:56px;padding:32px;max-width:780px;margin-left:auto;margin-right:auto}}

/* ── Stats bar ── */
.stats-bar{{background:var(--primary);color:#fff;padding:32px 0}}
.stats-grid{{display:grid;grid-template-columns:repeat(4,1fr);text-align:center;gap:16px}}
.stat-value{{font-family:{fh};font-size:2rem}}
.stat-label{{font-size:13px;opacity:.8;margin-top:4px}}

/* ── Section headings ── */
.section-label{{font-size:12px;font-weight:600;letter-spacing:.1em;text-transform:uppercase;color:var(--primary);margin-bottom:12px}}
.section-title{{font-size:clamp(1.6rem,3vw,2.4rem)}}
.section-sub{{font-size:17px;color:var(--mid);margin-top:12px;max-width:560px}}
.section-sub.centered{{margin-left:auto;margin-right:auto}}

/* ── Feature cards ── */
.feature-card{{background:var(--white);border:1px solid var(--border);border-radius:var(--radius);padding:28px;transition:.2s}}
.feature-card:hover{{box-shadow:var(--shadow);transform:translateY(-2px)}}
.feature-icon{{font-size:28px;margin-bottom:12px}}
.feature-name{{font-size:17px;font-weight:600;margin-bottom:8px;font-family:{fh}}}
.feature-desc{{font-size:14px;color:var(--mid);line-height:1.6}}

/* ── How it works ── */
.how-step{{display:flex;gap:20px;align-items:flex-start}}
.step-num{{width:40px;height:40px;border-radius:50%;background:var(--primary-light);color:var(--primary);font-size:16px;font-weight:700;display:flex;align-items:center;justify-content:center;flex-shrink:0;font-family:{fh}}}
.step-title{{font-size:17px;font-weight:600;font-family:{fh};margin-bottom:6px}}
.step-desc{{font-size:14px;color:var(--mid)}}

/* ── Testimonials ── */
.testimonial-card{{background:var(--white);border:1px solid var(--border);border-radius:var(--radius);padding:28px}}
.testimonial-stars{{color:var(--accent);font-size:15px;margin-bottom:12px}}
.testimonial-quote{{font-size:15px;color:var(--dark);line-height:1.65;font-style:italic}}
.testimonial-author{{font-size:13px;color:var(--mid);margin-top:16px;font-weight:600}}

/* ── FAQ accordion ── */
.faq-item{{border-bottom:1px solid var(--border)}}
.faq-q{{width:100%;text-align:left;background:none;border:none;padding:20px 0;font-size:15px;font-weight:600;cursor:pointer;display:flex;justify-content:space-between;align-items:center;font-family:{fb};color:var(--dark)}}
.faq-q:hover{{color:var(--primary)}}
.faq-icon{{font-size:18px;transition:.25s;color:var(--primary)}}
.faq-a{{max-height:0;overflow:hidden;transition:.3s ease;font-size:14px;color:var(--mid)}}
.faq-a.open{{max-height:200px;padding-bottom:16px}}
.faq-icon.open{{transform:rotate(45deg)}}

/* ── CTA section ── */
.cta-section{{background:var(--primary);color:#fff;text-align:center;padding:80px 0}}
.cta-section h2{{font-size:clamp(1.8rem,3vw,2.4rem);color:#fff}}
.cta-section p{{font-size:17px;opacity:.85;margin-top:12px}}
.cta-section .btn-accent{{margin-top:32px;font-size:17px}}

/* ── Pricing ── */
.pricing-grid{{display:grid;grid-template-columns:repeat(3,1fr);gap:24px;align-items:start}}
.plan-card{{background:var(--white);border:1px solid var(--border);border-radius:16px;padding:32px;position:relative}}
.plan-card.popular{{border:2px solid var(--primary);box-shadow:0 4px 24px rgba(26,107,74,.15)}}
.popular-badge{{position:absolute;top:-13px;left:50%;transform:translateX(-50%);background:var(--primary);color:#fff;font-size:11px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;padding:4px 16px;border-radius:20px;white-space:nowrap}}
.plan-name{{font-size:14px;font-weight:700;letter-spacing:.05em;text-transform:uppercase;color:var(--primary)}}
.plan-price{{font-family:{fh};font-size:3rem;line-height:1;margin:12px 0 4px}}
.plan-period{{font-size:13px;color:var(--mid)}}
.plan-position{{font-size:14px;color:var(--mid);margin:12px 0 20px;min-height:36px}}
.plan-features{{list-style:none;margin:20px 0;border-top:1px solid var(--border);padding-top:20px}}
.plan-feature{{display:flex;gap:10px;font-size:14px;padding:5px 0;color:var(--dark)}}
.plan-feature.excluded{{color:var(--mid)}}
.check{{color:var(--primary);font-weight:700}}
.cross{{color:#d1d5db}}
.plan-cta{{display:block;width:100%;text-align:center;margin-top:24px;padding:14px}}

/* ── Comparison table ── */
.comp-table{{width:100%;border-collapse:collapse;margin-top:32px}}
.comp-table th{{padding:12px 16px;text-align:left;font-size:13px;font-weight:600;border-bottom:2px solid var(--border);color:var(--mid)}}
.comp-table th.hl{{color:var(--primary)}}
.comp-table td{{padding:12px 16px;font-size:14px;border-bottom:1px solid var(--border);vertical-align:middle}}
.comp-table tr:last-child td{{border-bottom:none}}
.comp-table .hl-col{{background:var(--primary-light);color:var(--primary);font-weight:600}}

/* ── Sign up form ── */
.signup-wrap{{display:grid;grid-template-columns:1fr 1fr;gap:64px;align-items:start}}
.signup-benefit{{display:flex;gap:12px;align-items:flex-start;margin-bottom:16px;font-size:15px}}
.signup-benefit-icon{{color:var(--primary);font-size:18px;margin-top:2px}}
.form-field{{margin-bottom:16px}}
.form-field label{{display:block;font-size:13px;font-weight:600;margin-bottom:6px;color:var(--dark)}}
.form-field input,.form-field select{{width:100%;padding:12px 14px;border:1.5px solid var(--border);border-radius:8px;font-size:15px;font-family:{fb};color:var(--dark);background:#fff;transition:.2s}}
.form-field input:focus,.form-field select:focus{{outline:none;border-color:var(--primary);box-shadow:0 0 0 3px rgba(26,107,74,.12)}}
.form-row{{display:grid;grid-template-columns:1fr 1fr;gap:12px}}
.plan-radio{{display:flex;gap:12px;margin-top:6px}}
.plan-radio label{{flex:1;border:1.5px solid var(--border);border-radius:8px;padding:10px 12px;cursor:pointer;font-size:13px;text-align:center;transition:.2s}}
.plan-radio input{{display:none}}
.plan-radio input:checked+span{{border-color:var(--primary);color:var(--primary);background:var(--primary-light)}}
.form-check{{display:flex;gap:10px;align-items:flex-start;font-size:13px;color:var(--mid);margin-bottom:16px}}
.form-check input{{margin-top:3px;accent-color:var(--primary)}}
.trust-badges{{display:flex;gap:16px;flex-wrap:wrap;margin-top:20px}}
.trust-badge{{font-size:12px;color:var(--mid)}}
.divider-or{{display:flex;align-items:center;gap:12px;color:var(--mid);font-size:13px;margin:16px 0}}
.divider-or::before,.divider-or::after{{content:'';flex:1;height:1px;background:var(--border)}}
.btn-google{{display:flex;align-items:center;justify-content:center;gap:10px;width:100%;padding:12px;border:1.5px solid var(--border);border-radius:8px;font-size:14px;font-weight:500;background:#fff;cursor:pointer;font-family:{fb};transition:.2s}}
.btn-google:hover{{background:var(--light)}}
.signup-quote{{background:var(--primary-light);border-left:3px solid var(--primary);border-radius:8px;padding:20px 24px;margin-top:32px;font-size:14px;color:var(--dark);font-style:italic}}
.signup-quote-author{{font-size:12px;color:var(--mid);margin-top:8px;font-style:normal;font-weight:600}}

/* ── Footer ── */
footer{{background:var(--dark);color:#9ca3af;padding:56px 0 32px}}
.footer-grid{{display:grid;grid-template-columns:2fr 1fr 1fr 1fr;gap:40px}}
.footer-brand-name{{font-family:{fh};font-size:20px;color:#fff;margin-bottom:12px}}
.footer-tagline{{font-size:14px;line-height:1.6}}
.footer-col-head{{font-size:12px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:#fff;margin-bottom:14px}}
.footer-links{{list-style:none}}
.footer-links li{{margin-bottom:8px}}
.footer-links a{{font-size:14px;color:#9ca3af}}
.footer-links a:hover{{color:#fff;text-decoration:none}}
.footer-bottom{{margin-top:48px;padding-top:24px;border-top:1px solid #374151;font-size:13px;text-align:center}}

/* ── Mockup checkbook ── */
.register-table{{width:100%;border-collapse:collapse;font-size:13px;text-align:left}}
.register-table th{{padding:8px 12px;border-bottom:2px solid var(--border);color:var(--mid);font-size:12px;font-weight:600;text-transform:uppercase;letter-spacing:.05em}}
.register-table td{{padding:10px 12px;border-bottom:1px solid var(--border);color:var(--dark)}}
.register-table tr:last-child td{{border-bottom:none}}
.balance-positive{{color:var(--primary);font-weight:600}}
.balance-negative{{color:#dc2626;font-weight:600}}
.tag{{display:inline-block;background:var(--primary-light);color:var(--primary);font-size:11px;padding:2px 8px;border-radius:12px;font-weight:600}}

/* ── Responsive ── */
@media(max-width:900px){{
  .grid-2,.grid-3,.pricing-grid,.signup-wrap,.footer-grid{{grid-template-columns:1fr}}
  .stats-grid{{grid-template-columns:repeat(2,1fr)}}
}}
@media(max-width:600px){{
  .nav-links{{display:none}}
  .hero{{padding:60px 0}}
  .section{{padding:56px 0}}
  .stats-grid{{grid-template-columns:1fr 1fr}}
  .form-row{{grid-template-columns:1fr}}
}}

/* ── Animations ── */
@keyframes fadeUp{{from{{opacity:0;transform:translateY(24px)}}to{{opacity:1;transform:translateY(0)}}}}
.animate{{animation:fadeUp .6s ease both}}
.delay-1{{animation-delay:.1s}}
.delay-2{{animation-delay:.2s}}
.delay-3{{animation-delay:.3s}}
"""


# ── Shared partials ───────────────────────────────────────────────────────────

def _nav(cfg):
    n = cfg["nav"]
    b = cfg["brand"]
    links_html = "".join(
        f'<li><a href="{l["href"]}">{l["label"]}</a></li>'
        for l in n["links"]
    )
    return f"""
<nav class="nav">
  <div class="container nav-inner">
    <a class="nav-logo" href="/">{b['name']}</a>
    <ul class="nav-links">{links_html}</ul>
    <a href="/login.html" class="nav-login">{n['login_label']}</a>
    <a href="{n['cta_href']}" class="btn btn-primary btn-sm nav-gap">{n['cta_label']}</a>
  </div>
</nav>"""


def _footer(cfg):
    f = cfg["footer"]
    b = cfg["brand"]
    cols_html = ""
    for col in f["columns"]:
        links = "".join(
            f'<li><a href="{l["href"]}">{l["label"]}</a></li>'
            for l in col["links"]
        )
        cols_html += f"""
    <div>
      <div class="footer-col-head">{col['heading']}</div>
      <ul class="footer-links">{links}</ul>
    </div>"""
    return f"""
<footer>
  <div class="container">
    <div class="footer-grid">
      <div>
        <div class="footer-brand-name">{b['name']}</div>
        <p class="footer-tagline">{f['tagline']}</p>
      </div>
      {cols_html}
    </div>
    <div class="footer-bottom">{f['copyright']}</div>
  </div>
</footer>"""


def _base(cfg, title, body, extra_head=""):
    b = cfg["brand"]
    s = cfg["seo"]
    css = cfg["_css"]
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{title} — {b['name']}</title>
<meta name="description" content="{s['description']}">
<meta property="og:title" content="{title} — {b['name']}">
<meta property="og:description" content="{s['description']}">
<meta property="og:url" content="{b['url']}">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:site" content="{s['twitter_handle']}">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="{b['google_font']}" rel="stylesheet">
<style>{css}</style>
{extra_head}
</head>
<body>
{_nav(cfg)}
{body}
{_footer(cfg)}
<script>
// FAQ accordion
document.querySelectorAll('.faq-q').forEach(btn => {{
  btn.addEventListener('click', () => {{
    const a = btn.nextElementSibling;
    const icon = btn.querySelector('.faq-icon');
    a.classList.toggle('open');
    icon.classList.toggle('open');
  }});
}});
</script>
</body>
</html>"""


# ── Page renderers ────────────────────────────────────────────────────────────

def _render_homepage(cfg, env):
    h = cfg["homepage"]
    b = cfg["brand"]

    # Stats
    stats_html = "".join(
        f'<div><div class="stat-value">{s["value"]}</div><div class="stat-label">{s["label"]}</div></div>'
        for s in h["stats"]
    )

    # Features
    features_html = "".join(
        f"""<div class="feature-card animate">
          <div class="feature-icon">{f['icon']}</div>
          <div class="feature-name">{f['name']}</div>
          <div class="feature-desc">{f['desc']}</div>
        </div>"""
        for f in h["features"]
    )

    # How it works
    steps_html = "".join(
        f"""<div class="how-step animate delay-{i+1}">
          <div class="step-num">{s['step']}</div>
          <div>
            <div class="step-title">{s['title']}</div>
            <div class="step-desc">{s['desc']}</div>
          </div>
        </div>"""
        for i, s in enumerate(h["how_it_works"])
    )

    # Testimonials
    testi_html = "".join(
        f"""<div class="testimonial-card animate">
          <div class="testimonial-stars">{"★" * t['stars']}</div>
          <div class="testimonial-quote">"{t['quote']}"</div>
          <div class="testimonial-author">{t['name']} · {t['role']}</div>
        </div>"""
        for t in h["testimonials"]
    )

    # FAQ
    faq_html = "".join(
        f"""<div class="faq-item">
          <button class="faq-q">{f['q']}<span class="faq-icon">+</span></button>
          <div class="faq-a"><p>{f['a']}</p></div>
        </div>"""
        for f in h["faq"]
    )

    # Hero mockup (sample checkbook register)
    mockup_rows = [
        ("Apr 1", "Opening balance",   "",       "2,450.00", "2,450.00", "", True),
        ("Apr 3", "Grocery run",        "Groceries","87.42",  "2,362.58", "💳", False),
        ("Apr 5", "Freelance payment",  "Income", "850.00",  "3,212.58", "💰", True),
        ("Apr 7", "Electric bill",      "Utilities","134.00", "3,078.58", "🔔", False),
        ("Apr 9", "Rent",               "Housing","1,200.00","1,878.58", "🏠", False),
    ]
    rows_html = ""
    for date, desc, cat, amt, bal, icon, is_income in mockup_rows:
        amt_class = "balance-positive" if is_income else "balance-negative"
        amt_sign  = "+" if is_income else "−"
        tag = f'<span class="tag">{cat}</span>' if cat else ""
        rows_html += f"""<tr>
          <td>{date}</td>
          <td>{icon} {desc} {tag}</td>
          <td class="{amt_class}">{amt_sign} ${amt}</td>
          <td class="balance-positive">${bal}</td>
        </tr>"""

    cta = h["final_cta"]
    hero = h["hero"]

    body = f"""
<!-- HERO -->
<section class="hero">
  <div class="container">
    <div class="section-label animate">Personal Finance Checkbook</div>
    <h1 class="animate delay-1">{hero['headline']}</h1>
    <p class="hero-sub animate delay-2">{hero['subheadline']}</p>
    <div class="hero-ctas animate delay-3">
      <a href="{hero['cta_primary']['href']}" class="btn btn-primary btn-lg">{hero['cta_primary']['label']}</a>
      <a href="{hero['cta_secondary']['href']}" class="btn btn-secondary btn-lg">{hero['cta_secondary']['label']}</a>
    </div>
    <p class="trust-line animate delay-3">{hero['trust_line']}</p>

    <!-- Live mockup -->
    <div class="hero-mockup animate delay-3">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px">
        <div>
          <div style="font-size:13px;color:var(--mid);font-weight:600;text-transform:uppercase;letter-spacing:.05em">April 2025 · Checking Account</div>
          <div style="font-family:{b['font_heading']};font-size:2rem;color:var(--primary);margin-top:4px">$1,878.58</div>
        </div>
        <div style="text-align:right">
          <div style="font-size:12px;color:var(--mid)">Income this month</div>
          <div style="font-size:16px;font-weight:600;color:var(--primary)">+$850.00</div>
          <div style="font-size:12px;color:var(--mid);margin-top:4px">Expenses this month</div>
          <div style="font-size:16px;font-weight:600;color:#dc2626">−$1,421.42</div>
        </div>
      </div>
      <table class="register-table">
        <thead>
          <tr>
            <th>Date</th><th>Description</th><th>Amount</th><th>Balance</th>
          </tr>
        </thead>
        <tbody>{rows_html}</tbody>
      </table>
    </div>
  </div>
</section>

<!-- STATS -->
<div class="stats-bar">
  <div class="container">
    <div class="stats-grid">{stats_html}</div>
  </div>
</div>

<!-- FEATURES -->
<section class="section" id="features">
  <div class="container">
    <div class="text-center mb-40">
      <div class="section-label">Features</div>
      <h2 class="section-title">Everything you need to stay on top of your money</h2>
      <p class="section-sub centered">Built around the simplicity of a paper checkbook — with just enough digital smarts to save you time.</p>
    </div>
    <div class="grid-auto">{features_html}</div>
  </div>
</section>

<!-- HOW IT WORKS -->
<section class="section" style="background:var(--primary-light)" id="how-it-works">
  <div class="container">
    <div class="grid-2">
      <div>
        <div class="section-label">How it works</div>
        <h2 class="section-title">Up and running in under 2 minutes</h2>
        <p class="section-sub mt-16">No tutorial required. If you've ever written a check, you already know how to use LedgerLite.</p>
      </div>
      <div style="display:flex;flex-direction:column;gap:28px">{steps_html}</div>
    </div>
  </div>
</section>

<!-- TESTIMONIALS -->
<section class="section" id="testimonials">
  <div class="container">
    <div class="text-center mb-40">
      <div class="section-label">What people say</div>
      <h2 class="section-title">Real households. Real results.</h2>
    </div>
    <div class="grid-3">{testi_html}</div>
  </div>
</section>

<!-- FAQ -->
<section class="section" style="background:var(--light)" id="faq">
  <div class="container" style="max-width:680px">
    <div class="text-center mb-40">
      <div class="section-label">FAQ</div>
      <h2 class="section-title">Common questions</h2>
    </div>
    <div>{faq_html}</div>
  </div>
</section>

<!-- FINAL CTA -->
<section class="cta-section">
  <div class="container">
    <h2>{cta['headline']}</h2>
    <p>{cta['subline']}</p>
    <a href="{cta['href']}" class="btn btn-accent btn-lg">{cta['button']}</a>
  </div>
</section>"""

    return _base(cfg, "Home", body)


def _render_pricing(cfg, env):
    p = cfg["pricing"]

    plans_html = ""
    for plan in p["plans"]:
        badge = '<div class="popular-badge">Most Popular</div>' if plan["popular"] else ""
        card_class = "plan-card popular" if plan["popular"] else "plan-card"
        price = f"${plan['monthly']}" if plan["monthly"] > 0 else "Free"
        annual_note = f"${plan['annual']}/mo billed annually" if plan["annual"] > 0 else "Always free"
        cta_class = "btn btn-primary plan-cta" if plan["popular"] else "btn btn-secondary plan-cta"

        features_html = "".join(
            f"""<li class="plan-feature {'excluded' if not f['included'] else ''}">
              <span class="{'check' if f['included'] else 'cross'}">{'✓' if f['included'] else '✗'}</span>
              {f['label']}
            </li>"""
            for f in plan["features"]
        )
        plans_html += f"""
        <div class="{card_class}">
          {badge}
          <div class="plan-name">{plan['name']}</div>
          <div class="plan-price">{price}</div>
          <div class="plan-period">{annual_note}</div>
          <div class="plan-position">{plan['position']}</div>
          <a href="{plan['href']}" class="{cta_class}">{plan['cta']}</a>
          <ul class="plan-features">{features_html}</ul>
        </div>"""

    faq_html = "".join(
        f"""<div class="faq-item">
          <button class="faq-q">{f['q']}<span class="faq-icon">+</span></button>
          <div class="faq-a"><p>{f['a']}</p></div>
        </div>"""
        for f in p["pricing_faq"]
    )

    body = f"""
<section class="section">
  <div class="container">
    <div class="text-center mb-40">
      <div class="section-label">Pricing</div>
      <h1 class="section-title">{p['headline']}</h1>
      <p class="section-sub centered">{p['subheadline']}</p>
    </div>
    <div class="pricing-grid">{plans_html}</div>

    <!-- Guarantee -->
    <div class="text-center mt-40" style="color:var(--mid);font-size:14px">
      <span style="font-size:24px">🛡️</span><br>
      <strong style="color:var(--dark)">30-day money-back guarantee.</strong><br>
      Not happy? We'll refund your first payment — no questions asked.
    </div>
  </div>
</section>

<!-- Pricing FAQ -->
<section class="section" style="background:var(--light)">
  <div class="container" style="max-width:680px">
    <div class="text-center mb-40">
      <h2 class="section-title">Billing questions</h2>
    </div>
    {faq_html}
  </div>
</section>"""

    return _base(cfg, "Pricing", body)


def _render_features(cfg, env):
    fp = cfg["features_page"]
    comp = fp["comparison"]

    # Deep features
    deep_html = ""
    for i, feat in enumerate(fp["deep_features"]):
        benefits_html = "".join(f"<li>{b}</li>" for b in feat["benefits"])
        img_side = f"""<div style="background:{feat['color']};border-radius:16px;min-height:280px;display:flex;align-items:center;justify-content:center;font-size:64px">{feat['icon']}</div>"""
        text_side = f"""<div>
          <div class="section-label">{feat['name']}</div>
          <p style="margin-top:12px;font-size:16px;line-height:1.7">{feat['para1']}</p>
          <p style="margin-top:12px;font-size:16px;line-height:1.7;color:var(--mid)">{feat['para2']}</p>
          <ul style="margin-top:20px;padding-left:20px;color:var(--primary);font-size:15px;line-height:2">{benefits_html}</ul>
        </div>"""
        if i % 2 == 0:
            deep_html += f'<div class="grid-2" style="margin-bottom:64px">{img_side}{text_side}</div>'
        else:
            deep_html += f'<div class="grid-2" style="margin-bottom:64px">{text_side}{img_side}</div>'

    # Comparison table
    col_heads = "".join(
        f'<th class="{"hl" if c["highlight"] else ""}">{c["name"]}</th>'
        for c in comp["columns"]
    )
    table_rows = ""
    for i, crit in enumerate(comp["criteria"]):
        cells = "".join(
            f'<td class="{"hl-col" if col["highlight"] else ""}">{col["values"][i]}</td>'
            for col in comp["columns"]
        )
        table_rows += f"<tr><td><strong>{crit}</strong></td>{cells}</tr>"

    body = f"""
<section class="section">
  <div class="container">
    <div class="text-center mb-40">
      <div class="section-label">Features</div>
      <h1 class="section-title">{fp['headline']}</h1>
      <p class="section-sub centered">{fp['subheadline']}</p>
    </div>
    {deep_html}
  </div>
</section>

<section class="section" style="background:var(--primary-light)">
  <div class="container">
    <div class="text-center mb-40">
      <h2 class="section-title">How does LedgerLite compare?</h2>
      <p class="section-sub centered">Honest, side-by-side comparison.</p>
    </div>
    <div style="overflow-x:auto">
      <table class="comp-table">
        <thead><tr><th>Feature</th>{col_heads}</tr></thead>
        <tbody>{table_rows}</tbody>
      </table>
    </div>
  </div>
</section>

<section class="cta-section">
  <div class="container">
    <h2>Ready to try it yourself?</h2>
    <p>No credit card. No bank login. Just clarity.</p>
    <a href="/signup.html" class="btn btn-accent btn-lg">Start for free</a>
  </div>
</section>"""

    return _base(cfg, "Features", body)


def _render_signup(cfg, env):
    s = cfg["signup"]
    b = cfg["brand"]

    benefits_html = "".join(
        f'<div class="signup-benefit"><span class="signup-benefit-icon">✓</span>{ben}</div>'
        for ben in s["benefits"]
    )
    badges_html = "".join(
        f'<span class="trust-badge">{badge}</span>'
        for badge in s["trust_badges"]
    )

    body = f"""
<section class="section">
  <div class="container">
    <div class="signup-wrap">

      <!-- Left: pitch -->
      <div>
        <div class="section-label">Get started free</div>
        <h1 class="section-title mt-8">{s['headline']}</h1>
        <div style="margin-top:28px">{benefits_html}</div>

        <div class="signup-quote">
          "{s['testimonial']['quote']}"
          <div class="signup-quote-author">— {s['testimonial']['author']}</div>
        </div>
      </div>

      <!-- Right: form -->
      <div>
        <div style="background:var(--white);border:1px solid var(--border);border-radius:16px;padding:36px;box-shadow:var(--shadow)">
          <h2 style="font-size:22px;margin-bottom:24px">Create your account</h2>

          <form onsubmit="return false">
            <div class="form-row">
              <div class="form-field">
                <label for="fname">First name</label>
                <input type="text" id="fname" placeholder="Jane">
              </div>
              <div class="form-field">
                <label for="lname">Last name</label>
                <input type="text" id="lname" placeholder="Smith">
              </div>
            </div>

            <div class="form-field">
              <label for="email">Email address</label>
              <input type="email" id="email" placeholder="jane@example.com">
            </div>

            <div class="form-field">
              <label for="pwd">Password</label>
              <input type="password" id="pwd" placeholder="At least 8 characters">
            </div>

            <div class="form-field">
              <label>Choose your plan</label>
              <div class="plan-radio">
                <label><input type="radio" name="plan" value="free" checked><span style="display:block;border:1.5px solid var(--border);border-radius:8px;padding:10px 12px;cursor:pointer;font-size:13px;text-align:center;transition:.2s">Free</span></label>
                <label><input type="radio" name="plan" value="pro"><span style="display:block;border:1.5px solid var(--border);border-radius:8px;padding:10px 12px;cursor:pointer;font-size:13px;text-align:center;transition:.2s">Pro · $6/mo</span></label>
                <label><input type="radio" name="plan" value="family"><span style="display:block;border:1.5px solid var(--border);border-radius:8px;padding:10px 12px;cursor:pointer;font-size:13px;text-align:center;transition:.2s">Family · $12/mo</span></label>
              </div>
            </div>

            <div class="form-check">
              <input type="checkbox" id="terms">
              <label for="terms">I agree to the <a href="/terms.html">Terms of Service</a> and <a href="/privacy.html">Privacy Policy</a></label>
            </div>

            <button type="submit" class="btn btn-primary" style="width:100%;padding:16px;font-size:16px">Create my account →</button>

            <div class="divider-or">or</div>

            <button type="button" class="btn-google">
              <svg width="18" height="18" viewBox="0 0 24 24"><path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/><path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/><path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z" fill="#FBBC05"/><path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/></svg>
              Continue with Google
            </button>
          </form>

          <p style="text-align:center;font-size:13px;color:var(--mid);margin-top:20px">
            Already have an account? <a href="/login.html">Log in</a>
          </p>

          <div class="trust-badges" style="justify-content:center;margin-top:16px">{badges_html}</div>
        </div>
      </div>

    </div>
  </div>
</section>"""

    return _base(cfg, "Sign Up", body)
