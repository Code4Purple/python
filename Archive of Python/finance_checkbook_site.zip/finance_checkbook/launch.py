#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════╗
║   Personal Finance Checkbook — Website Launcher          ║
║   Run: python launch.py                                  ║
║   Then open: http://localhost:8080                       ║
╚══════════════════════════════════════════════════════════╝

What this does:
  1. Checks & installs all required Python packages
  2. Generates all HTML pages from your config
  3. Starts a local web server
  4. Opens your browser automatically

Edit config.py to customize brand, copy, pricing, and features.
"""

import sys
import os
import subprocess
import importlib

# ── 1. Auto-install dependencies ──────────────────────────────────────────────
REQUIRED = ["jinja2"]

def install_deps():
    missing = []
    for pkg in REQUIRED:
        try:
            importlib.import_module(pkg)
        except ImportError:
            missing.append(pkg)
    if missing:
        print(f"[setup] Installing: {', '.join(missing)} ...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "--quiet"] + missing)
        print("[setup] Done.\n")

install_deps()

# ── 2. Now import everything ───────────────────────────────────────────────────
import http.server
import socketserver
import webbrowser
import threading
import shutil
from pathlib import Path

from generator import build_site
from config import SITE_CONFIG

# ── 3. Build the site ─────────────────────────────────────────────────────────
PORT = 8080
OUTPUT_DIR = Path(__file__).parent / "dist"

def main():
    print("\n╔══════════════════════════════════════════════╗")
    print("║  Finance Checkbook — Site Launcher           ║")
    print("╚══════════════════════════════════════════════╝\n")

    print("[1/3] Building site from config...")
    build_site(SITE_CONFIG, OUTPUT_DIR)
    print(f"      ✓ Site generated → {OUTPUT_DIR}/\n")

    print(f"[2/3] Starting server on http://localhost:{PORT}")
    os.chdir(OUTPUT_DIR)

    handler = http.server.SimpleHTTPRequestHandler
    handler.log_message = lambda *a: None  # suppress request noise

    with socketserver.TCPServer(("", PORT), handler) as httpd:
        print(f"      ✓ Server running\n")
        print(f"[3/3] Opening browser → http://localhost:{PORT}")
        print("\n      Press Ctrl+C to stop.\n")
        print("─" * 50)

        def open_browser():
            import time
            time.sleep(0.8)
            webbrowser.open(f"http://localhost:{PORT}")

        t = threading.Thread(target=open_browser, daemon=True)
        t.start()

        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\n\n[stopped] Server shut down. Run again anytime with: python launch.py\n")

if __name__ == "__main__":
    main()
