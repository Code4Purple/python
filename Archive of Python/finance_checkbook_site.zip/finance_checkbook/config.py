"""
╔══════════════════════════════════════════════════════════╗
║   config.py — Your Website's Single Source of Truth     ║
║                                                          ║
║   Edit anything here and re-run launch.py to            ║
║   instantly rebuild the whole site.                      ║
╚══════════════════════════════════════════════════════════╝
"""

SITE_CONFIG = {

    # ── Brand ─────────────────────────────────────────────────────────────────
    "brand": {
        "name": "LedgerLite",
        "tagline": "Your money. Crystal clear.",
        "description": "A personal finance checkbook app for everyday households.",
        "url": "https://ledgerlite.app",
        "support_email": "hello@ledgerlite.app",
        "google_font": "https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600&family=DM+Serif+Display&display=swap",
        "font_heading": "'DM Serif Display', serif",
        "font_body": "'DM Sans', sans-serif",
        "colors": {
            "primary":        "#1a6b4a",   # deep green — trust, growth
            "primary_light":  "#e6f4ee",   # tint for backgrounds
            "primary_mid":    "#2d9e6e",   # hover states
            "accent":         "#f0a500",   # amber — attention, CTAs
            "dark":           "#111827",   # near-black text
            "mid":            "#6b7280",   # secondary text
            "light":          "#f9fafb",   # page background
            "white":          "#ffffff",
            "border":         "#e5e7eb",
        },
    },

    # ── SEO & Meta ────────────────────────────────────────────────────────────
    "seo": {
        "title":       "LedgerLite — Personal Finance Checkbook",
        "description": "Track income, expenses, and balance in minutes. LedgerLite is the digital checkbook for everyday households.",
        "og_image":    "/images/og-cover.png",
        "twitter_handle": "@ledgerlite",
    },

    # ── Navigation ────────────────────────────────────────────────────────────
    "nav": {
        "links": [
            {"label": "Features",   "href": "/features.html"},
            {"label": "Pricing",    "href": "/pricing.html"},
            {"label": "How it works","href": "/#how-it-works"},
            {"label": "FAQ",        "href": "/#faq"},
        ],
        "cta_label": "Start for free",
        "cta_href":  "/signup.html",
        "login_label": "Log in",
        "login_href":  "/login.html",
    },

    # ── Homepage ──────────────────────────────────────────────────────────────
    "homepage": {
        "hero": {
            "headline":    "Finally know exactly where your money goes.",
            "subheadline": "LedgerLite is a simple digital checkbook that tracks every dollar — no spreadsheets, no subscriptions maze, no confusion.",
            "cta_primary":   {"label": "Start tracking free", "href": "/signup.html"},
            "cta_secondary": {"label": "See how it works",    "href": "/#how-it-works"},
            "trust_line":    "No credit card required · 10,000+ households already tracking",
        },

        "stats": [
            {"value": "10,000+", "label": "Active households"},
            {"value": "$2.4M",   "label": "Tracked this month"},
            {"value": "4.9★",    "label": "Average rating"},
            {"value": "2 min",   "label": "Average setup time"},
        ],

        "features": [
            {
                "icon": "📒",
                "name": "Digital Checkbook Register",
                "desc": "Log every income and expense exactly like a paper checkbook — but faster, searchable, and always balanced."
            },
            {
                "icon": "💰",
                "name": "Running Balance",
                "desc": "See your real balance update instantly with every entry. No mental math, no end-of-month surprises."
            },
            {
                "icon": "🏷️",
                "name": "Category Tagging",
                "desc": "Tag transactions with custom categories and see exactly where your money flows each month."
            },
            {
                "icon": "📊",
                "name": "Monthly Summaries",
                "desc": "Auto-generated income vs. expense reports every month so you can spot trends without lifting a finger."
            },
            {
                "icon": "🔔",
                "name": "Bill Reminders",
                "desc": "Set recurring entries for bills and get reminders before they hit — never miss a due date again."
            },
            {
                "icon": "☁️",
                "name": "Works Anywhere",
                "desc": "Your data syncs across phone, tablet, and desktop. Start on your phone, review on your laptop."
            },
        ],

        "how_it_works": [
            {
                "step": "1",
                "title": "Add your starting balance",
                "desc": "Enter your current bank balance once to get started. LedgerLite takes it from there — no bank connection required."
            },
            {
                "step": "2",
                "title": "Log income and expenses as they happen",
                "desc": "Takes 10 seconds per entry. Add a description, amount, category, and date — your balance updates in real time."
            },
            {
                "step": "3",
                "title": "Watch your money make sense",
                "desc": "Your monthly summary, category breakdown, and running balance are always up to date. No end-of-month catch-up needed."
            },
        ],

        "testimonials": [
            {
                "name":  "Sandra Kowalski",
                "role":  "Stay-at-home parent, Ohio",
                "stars": 5,
                "quote": "I used to dread checking my bank account. LedgerLite changed that completely. I know my balance to the dollar every single day now, and I finally stopped overdrafting."
            },
            {
                "name":  "Marcus Tillman",
                "role":  "Freelance contractor, Texas",
                "stars": 5,
                "quote": "My income is irregular so budgeting apps never worked for me. This is just a checkbook — log what comes in, log what goes out. Simple. It's the only app I've stuck with."
            },
            {
                "name":  "Priya Nair",
                "role":  "Nurse, California",
                "stars": 5,
                "quote": "I tried Mint, YNAB, and a dozen others. They all overwhelmed me. LedgerLite is just a clean register. I was set up in under 5 minutes and I've used it every day for 8 months."
            },
        ],

        "faq": [
            {
                "q": "Is my bank account connected?",
                "a": "No — and that's by design. LedgerLite is a manual checkbook register. You enter transactions yourself, which means your bank credentials are never shared with anyone."
            },
            {
                "q": "Is the free plan actually usable?",
                "a": "Yes. The free plan gives you unlimited transaction entries, running balance, and monthly summaries. Pro adds categories, reminders, and multi-account tracking."
            },
            {
                "q": "Can I use it on my phone?",
                "a": "Yes. LedgerLite works in any browser on any device — phone, tablet, or desktop. A native app is on the roadmap for Pro users."
            },
            {
                "q": "What if I want to cancel?",
                "a": "Cancel any time from your account settings. You keep access until the end of your billing period, and you can export all your data as a CSV before you go."
            },
            {
                "q": "Is my data private?",
                "a": "Absolutely. Your transaction data is encrypted at rest and in transit, and is never sold or shared with third parties — ever."
            },
        ],

        "final_cta": {
            "headline": "Take control of your money today.",
            "subline":  "Join 10,000+ households who finally know where every dollar goes.",
            "button":   "Start for free — no card needed",
            "href":     "/signup.html",
        },
    },

    # ── Pricing Page ──────────────────────────────────────────────────────────
    "pricing": {
        "headline":    "Simple, honest pricing.",
        "subheadline": "Start free. Upgrade only when you're ready.",
        "plans": [
            {
                "name":       "Free",
                "monthly":    0,
                "annual":     0,
                "position":   "Perfect for getting started",
                "popular":    False,
                "cta":        "Start for free",
                "href":       "/signup.html",
                "features": [
                    {"label": "Unlimited transaction entries",  "included": True},
                    {"label": "Running balance tracker",        "included": True},
                    {"label": "Monthly income/expense summary", "included": True},
                    {"label": "Single account",                 "included": True},
                    {"label": "Category tagging",               "included": False},
                    {"label": "Bill reminders",                 "included": False},
                    {"label": "Multi-account tracking",         "included": False},
                    {"label": "CSV data export",                "included": False},
                ],
            },
            {
                "name":       "Pro",
                "monthly":    6,
                "annual":     4,
                "position":   "For serious personal finance",
                "popular":    True,
                "cta":        "Start 14-day free trial",
                "href":       "/signup.html?plan=pro",
                "features": [
                    {"label": "Everything in Free",             "included": True},
                    {"label": "Category tagging & reports",     "included": True},
                    {"label": "Bill & recurring reminders",     "included": True},
                    {"label": "Up to 3 accounts",               "included": True},
                    {"label": "CSV data export",                "included": True},
                    {"label": "Priority email support",         "included": True},
                    {"label": "Multi-account tracking",         "included": False},
                    {"label": "Family sharing (up to 5)",       "included": False},
                ],
            },
            {
                "name":       "Family",
                "monthly":    12,
                "annual":     8,
                "position":   "For households tracking together",
                "popular":    False,
                "cta":        "Start 14-day free trial",
                "href":       "/signup.html?plan=family",
                "features": [
                    {"label": "Everything in Pro",              "included": True},
                    {"label": "Up to 5 family members",         "included": True},
                    {"label": "Unlimited accounts",             "included": True},
                    {"label": "Shared household ledger",        "included": True},
                    {"label": "Per-member spending view",       "included": True},
                    {"label": "Dedicated support",              "included": True},
                    {"label": "CSV data export",                "included": True},
                    {"label": "Early access to new features",   "included": True},
                ],
            },
        ],
        "pricing_faq": [
            {
                "q": "Does the free trial require a credit card?",
                "a": "No. Start your 14-day Pro or Family trial with just your email address. We only ask for payment if you decide to keep it."
            },
            {
                "q": "Can I switch plans later?",
                "a": "Yes, upgrade or downgrade any time from your account settings. Downgrades take effect at the next billing cycle."
            },
            {
                "q": "What happens to my data if I cancel?",
                "a": "Your data stays in your account for 30 days after cancellation. You can export a full CSV any time before then."
            },
            {
                "q": "Is there a discount for annual billing?",
                "a": "Yes — annual billing saves you up to 33% compared to monthly. The annual price is shown per month when you toggle above."
            },
        ],
    },

    # ── Features Page ─────────────────────────────────────────────────────────
    "features_page": {
        "headline":    "Everything you need. Nothing you don't.",
        "subheadline": "LedgerLite is built around one idea: financial clarity shouldn't be complicated.",
        "deep_features": [
            {
                "name":  "Digital Checkbook Register",
                "icon":  "📒",
                "color": "#e6f4ee",
                "para1": "The checkbook register is the foundation of LedgerLite. Every entry is a single row: date, description, amount, and category. Your running balance updates the instant you hit save.",
                "para2": "Unlike spreadsheets that break when you edit a formula, the register is bulletproof. Sort, filter, and search across months of history in seconds.",
                "benefits": [
                    "Enter a transaction in under 10 seconds",
                    "Running balance never goes stale",
                    "Search and filter across all history",
                ],
            },
            {
                "name":  "Category Tagging & Reports",
                "icon":  "🏷️",
                "color": "#fff7e6",
                "para1": "Assign any transaction to a category you define — Groceries, Rent, Side Income, whatever fits your life. Categories are yours, not locked to a preset list.",
                "para2": "At the end of every month, LedgerLite rolls up your categories into a clear income vs. expense report. See exactly where money came from and where it went.",
                "benefits": [
                    "Custom categories that match your actual life",
                    "Monthly category breakdown auto-generated",
                    "Spot overspending patterns instantly",
                ],
            },
            {
                "name":  "Bill & Recurring Reminders",
                "icon":  "🔔",
                "color": "#eef2ff",
                "para1": "Set any transaction as recurring — monthly rent, weekly groceries, annual subscriptions — and LedgerLite will remind you before it's due and pre-fill the entry for you.",
                "para2": "You always know what's coming in the next 30 days so you can plan ahead, not react to overdrafts.",
                "benefits": [
                    "Never miss a bill or due date again",
                    "Recurring entries pre-fill automatically",
                    "30-day upcoming payment view",
                ],
            },
        ],
        "comparison": {
            "criteria": [
                "Setup time",
                "Requires bank login",
                "Works offline",
                "Manual control",
                "Beginner friendly",
                "Bill reminders",
                "Monthly reports",
                "Cost",
            ],
            "columns": [
                {
                    "name": "LedgerLite",
                    "highlight": True,
                    "values": ["2 minutes", "Never", "Yes", "Full", "Very easy", "Yes", "Auto", "Free / $6/mo"],
                },
                {
                    "name": "Spreadsheet",
                    "highlight": False,
                    "values": ["Hours", "No", "Yes", "Full", "Hard", "Manual", "Manual", "Free*"],
                },
                {
                    "name": "Budgeting Apps",
                    "highlight": False,
                    "values": ["30 min+", "Required", "Limited", "Low", "Medium", "$10–15/mo", "Auto", "$10–15/mo"],
                },
            ],
        },
    },

    # ── Sign Up Page ──────────────────────────────────────────────────────────
    "signup": {
        "headline":   "Start tracking your money today.",
        "benefits": [
            "Set up in under 2 minutes",
            "No bank connection required — your data stays yours",
            "Cancel or export your data any time",
        ],
        "testimonial": {
            "quote":  "The only finance app I've actually stuck with. Simple and honest.",
            "author": "Marcus T., Texas",
        },
        "trust_badges": [
            "🔒 SSL encrypted",
            "✉️ No credit card needed",
            "↩️ Cancel anytime",
        ],
    },

    # ── Footer ────────────────────────────────────────────────────────────────
    "footer": {
        "tagline": "Simple finance tracking for real households.",
        "columns": [
            {
                "heading": "Product",
                "links": [
                    {"label": "Features",    "href": "/features.html"},
                    {"label": "Pricing",     "href": "/pricing.html"},
                    {"label": "How it works","href": "/#how-it-works"},
                    {"label": "Changelog",   "href": "/changelog.html"},
                ],
            },
            {
                "heading": "Account",
                "links": [
                    {"label": "Sign up",  "href": "/signup.html"},
                    {"label": "Log in",   "href": "/login.html"},
                    {"label": "Settings", "href": "/settings.html"},
                    {"label": "Export data","href": "/export.html"},
                ],
            },
            {
                "heading": "Support",
                "links": [
                    {"label": "FAQ",          "href": "/#faq"},
                    {"label": "Contact us",   "href": "/contact.html"},
                    {"label": "Privacy policy","href": "/privacy.html"},
                    {"label": "Terms of use", "href": "/terms.html"},
                ],
            },
        ],
        "copyright": "© 2025 LedgerLite. All rights reserved.",
    },

}
