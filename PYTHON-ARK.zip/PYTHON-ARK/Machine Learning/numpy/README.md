Bookmark:  https://youtu.be/4LIAHVXnpbY?list=PLCC34OHNcOtpalASMlX2HHdsLNipyyhbK&t=1

install pip numpy