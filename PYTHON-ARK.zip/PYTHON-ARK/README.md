

Right now I am exploring Numpy Library to see if we can use this as a ML used for ML Apps.


